package arraylistbasicoperations;



public class ArrayListBasicOperations {


    public static void main(String[] args) {
        fruitClass fruit1 = new fruitClass();
        
        fruit1.firstLastFruit();
        fruit1.changeSecondFruit();
        fruit1.newList();
        fruit1.printFruits();
    }
    
}
